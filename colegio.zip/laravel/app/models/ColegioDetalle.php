<?php
class ColegioDetalle extends Base
{
	public $table = "colegios_detalle";
}
?>
