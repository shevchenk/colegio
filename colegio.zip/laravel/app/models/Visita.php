<?php
class Visita extends Base
{
    public $table = "visitas";

}
?>
