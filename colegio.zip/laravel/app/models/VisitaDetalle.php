<?php
class VisitaDetalle extends Base
{
    public $table = "visitas_detalle";

}
?>
