<h2><strong>Se&ntilde;or(a):</strong>&nbsp;{{ $persona }}</h2>

<h3>{{ $area }}</h3>

<p>&nbsp;</p>

<p>Reciba usted mi saludo cordial</p>

<p>&nbsp;</p>

<p>Le informo lo siguiente:</p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Acabo de crear la ruta llamada <strong>{{ $procesoe }}</strong> en la que he considerado al &aacute;rea donde usted labora en el <strong>PASO {{ $paso }}.</strong></p>

<p>&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Por ello, le solicito que incluya usted sus acciones y los tiempos a dicho paso. Cabe indicar que, mientras usted no ingrese las acciones que le corresponde a su &aacute;rea no podr&eacute; enviar el proceso al estado de producci&oacute;n, generando que no se pueda dar soluci&oacute;n a los requerimientos de los usuarios.</p>

<p>&nbsp;</p>

<p>Atentamente;</p>

<p>&nbsp;</p>

<p><strong>&nbsp;{{ $personae }}</strong></p>

<p><strong>&nbsp;Due&ntilde;o de proceso </strong></p>

<p><strong>&nbsp;{{ $areae }}</strong></p>
