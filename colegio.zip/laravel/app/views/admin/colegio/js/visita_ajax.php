<script type="text/javascript">
var CargoObj;
var Visita={
    Colegio:function(evento){
        var datos=$("#form_vista").serialize().split("txt_").join("").split("slct_").join("");
        $.ajax({
            url         : 'colegio/cargar',
            type        : 'POST',
            cache       : false,
            dataType    : 'json',
            data        : datos,
            beforeSend : function() {
                $("body").append('<div class="overlay"></div><div class="loading-img"></div>');
            },
            success : function(obj) {
                $(".overlay,.loading-img").remove();
                evento(obj.aData);
                if( obj.aData.length==0 ){
                    msjG.mensaje("danger","No hay colegios para el distrito seleccionado",5000);
                }
            },
            error: function(){
                $(".overlay,.loading-img").remove();
                msjG.mensaje("danger","Ocurrio una interrupción en el proceso,Favor de intentar nuevamente.",3000);
            }
        });
    },
    ColegioDetalle:function(evento){
        var datos=$("#form_vista").serialize().split("txt_").join("").split("slct_").join("");
        $.ajax({
            url         : 'colegio/cargardetalle',
            type        : 'POST',
            cache       : false,
            dataType    : 'json',
            data        : datos,
            beforeSend : function() {
                $("body").append('<div class="overlay"></div><div class="loading-img"></div>');
            },
            success : function(obj) {
                $(".overlay,.loading-img").remove();
                evento(obj.aData);
                if( obj.aData.length==0 ){
                    msjG.mensaje("danger","No hay colegios para el distrito seleccionado",5000);
                }
            },
            error: function(){
                $(".overlay,.loading-img").remove();
                msjG.mensaje("danger","Ocurrio una interrupción en el proceso,Favor de intentar nuevamente.",3000);
            }
        });
    },
    Crear:function(evento){
        var datos=$("#form_vista").serialize().split("txt_").join("").split("slct_").join("");
        $.ajax({
            url         : 'visita/crear',
            type        : 'POST',
            cache       : false,
            dataType    : 'json',
            data        : datos,
            beforeSend : function() {
                $("body").append('<div class="overlay"></div><div class="loading-img"></div>');
            },
            success : function(obj) {
                $(".overlay,.loading-img").remove();
                evento();
                msjG.mensaje("success",obj.msj,3000);
            },
            error: function(){
                $(".overlay,.loading-img").remove();
                msjG.mensaje("danger","Ocurrio una interrupción en el proceso,Favor de intentar nuevamente.",3000);
            }
        });
    }
};
</script>
